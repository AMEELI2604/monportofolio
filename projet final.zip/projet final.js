// Affiche un message pour un projet sélectionné
function showDetails(projectName) {
    alert(Vous avez sélectionné : ${projectName});
}

// Gestion du formulaire de contact
document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    alert(Merci, ${name}! Votre message a été envoyé.);
    console.log(Nom: ${name}, Email: ${email}, Message: ${message});
    this.reset(); // Réinitialise le formulaire
});